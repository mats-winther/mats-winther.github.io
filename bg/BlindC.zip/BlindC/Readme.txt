

BLINDCHESS v.1.76


BlindChess for DOS is intended for blindfold chess training. But it can also be set to show the board. The program will also work under all Windows versions. If you own PocketDOS it will run on your palmtop device. It works finely on my Casio BE-300. You input moves at the command prompt by typing, e.g., 'g1f3'. Whenever you want you can display an ascii diagram of the board position. The program's response time depends only on the setting of search depth. On a modern computer, it replies instantaneously at 5 ply (that is, 5 ply minimum), which is the default setting. This can be changed with the command 'sd'. It is a minimax brute force program, with some positional intelligence, which is good enough for blindfold chess. The three-time repetition rule is not enforced, otherwise it's a fully adequate chess program. 

You can interrupt processing by typing any key. When setting up a position you will be asked if you want to change the default, namely whether castling is still allowed. 'En passant' positions can also be specified. When placing, for instance, a King at e2, input 'Ke2', or 'ke2'. If you want to empty the position, input '.e2', that is, a period instead of a piece designator. Although it's only possible to take back a half-move, the 'input position' function can be used when taking back further moves. It is easy to use. The print function supports Auto232 and Chess232 (hopefully). Game moves can also be printed to a file (game.txt). Whenever a new game, or position, is initialized, the file is closed. If the print ('pf') is started again, the new game is appended to the file. The start position, if it's not the standard initial position, is always printed before the moves. This form of move text can be read by TascBase. I don't know about other chess databases. If printing to LPT is on, it will be turned off if you start a new game. 

The program also supports Chess256, that is, randomization of the pawns on the second and third rank. Try it! It is a good way of avoiding opening monotony. This function can be used as a randomizer when playing Chess256 on a real board. The program will sometimes play what it regards as the second best move. This creates variable play and makes the program deviate from move repetitions, but it also means that it will make bad moves sometimes. You can turn blind mode off, that it, make the board visible all the time. You can set character size in the DOS window to achieve the best looking board image. The board probably looks best in full screen mode. In older windows versions 'privileged mode' should also be set. Certain default values can also be set in the ini-file. Unlike most other programs, this program will not always make the same move in the same position. 

Former World Champion Tigran Petrosian said that he learned to calculate by reading chess books, and by trying to manage without a chess board between the diagrams. This blindfold chess program is ideal for this type of training.

� Mats Winther, January  2007




__________________________________________________

BlindChess Home page: (check for updates!)
http://hem.passagen.se/melki9/blindc.htm

My Chess Variants page:
http://hem.passagen.se/melki9/chessvar.htm
___________________________________________________


BlindChess 1.76. Kernel algorithms by courtesy of Steinwender/Donninger (Minimax)


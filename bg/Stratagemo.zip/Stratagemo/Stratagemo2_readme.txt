Stratagemo2.zrf plays Stratego according to standard rules, that is, the Disarmer cannot defuse friendly mines. Otherwise it's exactly the same as Stratagemo.zrf.

-------------
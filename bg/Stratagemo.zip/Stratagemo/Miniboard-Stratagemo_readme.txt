Miniboard-Stratagemo is exactly the same as Stratagemo. The only 
difference is the board size. 

The small board and pieces are suitable for creating diagrams. 
To create a diagram press 'Print Screen'. Point at any image 
editor and press ctrl-v. Cut the image, reduce number of 
colours and save as gif.

If you want to transfer games between Miniboard-Stratagemo and 
Stratagemo you must change program name in the game file
by editing it.

-------------
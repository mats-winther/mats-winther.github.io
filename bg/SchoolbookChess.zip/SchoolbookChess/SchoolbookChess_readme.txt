SCHOOLBOOK CHESS 

Invented by Sam Trenholme. Implemented by Mats Winther.
----------------------------------------------------------------------------------------------------------

In Schoolbook Chess two new pieces are introduced (1) Archbishop (Princess/Cardinal) 
which slides like a Bishop or leaps like a Knight (2) Marshall (Empress/Chancellor) which 
slides like a Rook or leaps like a Knight. The king may castle two or three squares towards 
the rook on the right hand side, and two, three, or four squares towards the rook on the 
left hand side. The rook leaps over the king to land besides the king. Other rules are similar 
to ordinary chess. Schoolbook Chess is one of many Capablanca variants. See also
http://hem.passagen.se/melki9/capablanca.htm

This Zillions implementation is tweaked to play better. Piece values have been altered by 
tweaking. Castling is encouraged. Early centre pawn moves are encouraged. Wasting 
king moves to the corners is discouraged. Early queen moves are discouraged. Diverse 
code improvements.

For more on Schoolbook Chess see:
http://www.chessvariants.org/index/msdisplay.php?itemid=MSschoolbook

-------------------------------------------------------------------------------------------------------------
To play you must have installed "Zillions of Games". Either double-click on 
SchoolbookChess.zrf or 
1. Run "Zillions of Games" 
2. Choose "Open Game Rules..." from the File menu 
3. Select "AdjutantChess.zrf" in the Open dialog and click "Open" 
AdjutantChess.zrf is a rules file used by the Windows program "Zillions of Games". 
Zillions of Games allows you to play any number of games against the computer 
or over the Internet. Zillions of Games can be purchased online. For more 
information please visit the Zillions of Games website www.zillions-of-games.com 

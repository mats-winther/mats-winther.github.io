Motti

(Implemented by Mats Winther, March 2006.)


The aim in this solitaire game is to evacuate the army corps (the big square) and save it from the onset of the surrounding enemy. To achieve this you must move it to the exit at the lower side. When positioned before the exit, win is achieved. Pieces move orthogonally to an empty square. Many solutions are possible. In the first variant it takes at least 81 moves. There are four additional variants. One of them is insoluble. (Which?). This game also exists as a variant in Zillions game "Sliding Puzzle", but in that implementation only one opening setup is given (and the graphics is different).
 
This game was published in Sweden, in the fifties, as "Motti-spelet" (Motti game). The game is known since the 19th century. In France it is called "L' Ane rouge" (The red donkey).




---------------------------------------------------------------
To play you must have installed "Zillions of Games". Either double-click on Motti.zrf or 
1. Run "Zillions of Games" 
2. Choose "Open Game Rules..." from the File menu 
3. Select "Motti.zrf" in the Open dialog and click "Open" 
Motti.zrf is a rules file used by the Windows program "Zillions of Games". Zillions of Games allows you to play any number of games against the computer or over the Internet. Zillions of Games can be purchased online. For more information please visit the Zillions of Games website www.zillions-of-games.com 
---------------------------------------------------------------
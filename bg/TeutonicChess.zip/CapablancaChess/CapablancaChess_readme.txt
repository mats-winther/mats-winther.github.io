Capablanca's Chess (and Teutonic Chess, Embassy Chess, Carrera's Chess, Bird's Chess)

implemented by Mats Winther (mlwi@swipnet.se), April 2006 

"Capablanca's Chess" is an invention of former World Champion Jos� Raul Capablanca (1888-1942). The board is 8x10. Two new pieces are introduced (1) Archbishop (Princess/Cardinal) which slides like a Bishop or leaps like a Knight (2) Chancellor (Empress/Marshall) which slides like a Rook or leaps like a Knight. Castling is performed by jumping three squares with the King instead of two. Other rules are similar to ordinary chess.

"Bird's Chess" was invented by the chess master Henry Bird in 1874. It is very similar to Capablanca's Chess and is probably the inspirational source of the latter. 

"Carrera's Chess" was invented by Pietro Carrera in the 17th century. He wrote a long book on chess, called 'Il Gioco delgi Scacchi', and published it in 1617 in Miltello in Sicily. This is the precursor of both Bird's Chess and Capablanca Chess. In the original rules there was no castle move, and a somewhat curious rule involving 'en passant'. This implementation introduces castling and regular 'en passant' rules.

"Teutonic Chess" is a variant of Capablanca's Chess, using a different setup, conceived by undersigned. It might seem superfluous to give it a new proper name when it is only a rearrangement of the initial position, but this is what people do. "Gothic Chess" is a patented version of Capablanca's Chess, the only difference being the initial setup. If you interchange the positions of Chancellor and Archbishop in Teutonic Chess you will get Gothic Chess.

Another variant is "Embassy Chess". It is too a variant of Capablanca's Chess, but the setup is different and the short castle is performed on the queenside. It was Kevin Hill that came up with this idea.


--------------------------------------------------------------------------------------
To play you must have installed "Zillions of Games". Either double-click on CapablancaChess.zrf or 
1. Run "Zillions of Games" 
2. Choose "Open Game Rules..." from the File menu 
3. Select "CapablancaChess.zrf" in the Open dialog and click "Open".

CapablancaChess.zrf is a rules file used by the Windows program "Zillions of Games". Zillions of Games allows you to play any number of games against the computer or over the Internet. Zillions of Games can be purchased online. For more information please visit the Zillions of Games website www.zillions-of-games.com 
--------------------------------------------------------------------------------------

